import pymysql

# 1. Install pymysql to locald irectory
# pip install -t $PWD pymysql

# 2. (If Using Lambda) Write your code, then zip it all up
# a) Mac/Linux --> zip -r9 ${PWD}/function.zip
# b) Windows --> Via Windows Explorer

# Lambda Permissions:
# AWSLambdaVPCAccessExecutionRole

# Configuration Values
endpoint = 'database-1.cuqf2iaxh6cf.us-east-1.rds.amazonaws.com'
username = 'admin'
password = "f3JKtJr^Pd3<LzB4v;}[!sP"
database_name = 'testing'

# Connection
connection = pymysql.connect(endpoint, user=username,
                             passwd=password, db=database_name)


def lambda_handler(event, context):
    cursor = connection.cursor()
    cursor.execute('SELECT * from testing')

    rows = cursor.fetchall()

    for row in rows:
        print("{0} {1} {2}".format(row[0], row[1], row[2]))
